package com.lti.jwt.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.jwt.dao.RoleDao;
import com.lti.jwt.dao.UserDao;
import com.lti.jwt.entity.Role;
import com.lti.jwt.entity.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	public User registerNewUser(User user) {
		return userDao.save(user);
	}
	@Autowired
	private RoleDao roleDao;
	public void initRolesAndUser() {
		Role adminRole = new Role();
		adminRole.setRoleName("admin");
		adminRole.setRoleDescription("admin role");
		roleDao.save(adminRole);
		
		Role userRole = new Role();
		userRole.setRoleName("user");
		userRole.setRoleDescription("Default user for newly created records");
		roleDao.save(userRole);
		
		User adminUser = new User();
		adminUser.setUserFirstName("admin");
		adminUser.setUserLastname("admin");
		adminUser.setUserName("admin@01");
		adminUser.setUserPassword("admin@123");
		Set<Role> adminRoles = new HashSet<>();
		adminUser.setRole(adminRoles);
		adminRoles.add(adminRole);
		userDao.save(adminUser);
		
		User user = new User();
		user.setUserFirstName("Ram");
		user.setUserLastname("Naik");
		user.setUserName("Ram01");
		user.setUserPassword("Ram@1234");
		Set<Role> userRoles = new HashSet<>();
		user.setRole(userRoles);
		userRoles.add(userRole);
		userDao.save(user);
		
		
	}

}
